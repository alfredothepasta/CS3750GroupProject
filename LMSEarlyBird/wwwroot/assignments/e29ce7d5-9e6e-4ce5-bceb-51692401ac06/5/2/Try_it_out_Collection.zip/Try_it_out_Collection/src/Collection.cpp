//
// Created by Jordan Allen on 9/6/22.
//

#include <iostream>
#include <stdexcept>
#include "Collection.h"

Collection::Collection(int Size) : arrayCapacity(Size) { valueArray = new double[Size];}

void Collection::Add(double value) {
    if(arrayTop > arrayCapacity){
        throw std::runtime_error("List Full");
    }

    arrayTop ++;
    valueArray[arrayTop] = value;
}

void Collection::AddFront(double value) {
    if(arrayTop > arrayCapacity){
        throw std::runtime_error("List Full");
    }

    arrayTop++;
    for(int i = arrayTop ; i > 0; i--){
        valueArray[i] = valueArray[i-1];
    }

    valueArray[0] = value;
}

double Collection::Get(int ndx) {
   if(ndx > arrayTop){
       throw std::out_of_range("Index is out of range");
   }

   return valueArray[ndx];
}

double Collection::GetFront() {
    if(arrayTop == -1){
        throw std::out_of_range("Array is Empty");
    }
    return valueArray[0];
}

double Collection::GetEnd() {
    if(arrayTop == -1){
        throw std::out_of_range("Array is Empty");
    }

    return valueArray[arrayTop];
}

int Collection::Find(double needle) {
    //linear search algorithm... because it didn't say I had to make it efficient
    for(int i = 0; i <= arrayTop; i++){
        if(valueArray[i] == needle)
            return i;
    }

    return -1;
}

std::ostream &operator<<(std::ostream &out, const Collection &c) {
    for(int i = 0; i <= c.arrayTop; i ++){
        out << c.valueArray[i];
        if(i < c.arrayTop){
            out << " ";
        }
    }

    return out;
}
