#include <iostream>
#include "src/Collection.h"
#include <sstream>

using namespace std;

void TestCollection();
void TestExceedSize();
void TestAddBeginning();
void TestExtractionOperator();
bool checkCase(std::string name, bool condition);

int main()
{
    TestCollection();
    TestExceedSize();
    TestAddBeginning();
    TestExtractionOperator();
    return 0;
}
void TestCollection(){
    Collection one;
    one.Add(2.2);
    one.Add(4.5);

    checkCase("Adding 1", one.Get(0) == 2.2);
    checkCase("Adding 2", one.Get(1) == 4.5);
    checkCase("Check Size", one.GetSize()== 2);
}
void TestExceedSize(){
    Collection one;
    for(int i = 0; i < one.GetCapacity(); i++){
        one.Add(i);
    }

    checkCase("Exceed Size 1", one.Get(0) == 0);
    checkCase("Exceed Size 2", one.Get(one.GetCapacity()-1) == one.GetCapacity()-1);


}
void TestAddBeginning(){
    Collection one;

    for(double i = 0; i < 5; i += 1){
        one.Add(i);
    }
    one.AddFront(2);
    checkCase("Add to Front Check 1", one.Get(0) == 2);
    checkCase("Add to Front Check 2", one.Get(5) == 4);
    checkCase("Add to Front Check 3", one.GetSize() == 6);


}
void TestExtractionOperator(){
    Collection one;
    one.Add(1);
    one.Add(2);
    stringstream sout;
    sout << one;
    checkCase("Overloaded Extraction Operator", sout.str() == "1 2");
}

bool checkCase(string name, bool condition){
    if(!condition){
        cout << "Failed: " << name << endl;
    }
    else{
        cout << name << ": passed" << endl;
    }
    return condition;
}
