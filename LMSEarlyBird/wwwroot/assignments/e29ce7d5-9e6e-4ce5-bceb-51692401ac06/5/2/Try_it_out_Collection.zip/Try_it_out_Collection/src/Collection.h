//
// Created by Jordan Allen on 9/6/22.
//

#ifndef TRY_IT_OUT_COLLECTION_COLLECTION_H
#define TRY_IT_OUT_COLLECTION_COLLECTION_H


class Collection {
private:
    double *valueArray;
    int arrayCapacity;
    int arrayTop = -1;

public:
    Collection() : arrayCapacity(10) { valueArray = new double[arrayCapacity];}

    explicit Collection(int Size);

    int GetSize() const {return arrayTop + 1;}

    int GetCapacity() const {return arrayCapacity;}

    void Add(double value);
    void AddFront(double value);

    double Get(int ndx);
    double GetFront();
    double GetEnd();

    int Find(double needle);

    friend std::ostream& operator<<(std::ostream& out, const Collection & c);
};


#endif //TRY_IT_OUT_COLLECTION_COLLECTION_H
